// default settins - this structure can be moved in separate file in multilangual applications
var A_TCALCONF = {
	'cssprefix'  : 'tc',
	'months'     : ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
	'weekdays'   : ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa'],
	'longwdays'  : ['Domingo', 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado'],
	'yearscroll' : false, // show year scroller
	'weekstart'  : 1, // first day of week: 0-Su or 1-Mo
	'prevyear'   : 'A�o anterior',
	'nextyear'   : 'Prox. a�o',
	'prevmonth'  : 'Mes anterior',
	'nextmonth'  : 'Prox. mes',
	'format'     : 'd-m-Y' // 'd-m-Y', Y-m-d', 'l, F jS Y'
};
