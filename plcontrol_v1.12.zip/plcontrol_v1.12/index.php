<?php
	( isset($_POST["MM_insert"]) && $_POST["MM_insert"] == "form2" )?
		include_once "pdfres.php" : include_once "form.php";
?>
